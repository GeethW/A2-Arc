package common;

import java.io.Serializable;

public class ContactUsData implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String customerName;
	private String msg;
	
	public ContactUsData() {
		customerName = null;
		msg = null;
	}
	
	public ContactUsData(String cName, String newMsg) {
		customerName = cName;
		msg = newMsg;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public String getMsg() {
		return msg;
	}

}
