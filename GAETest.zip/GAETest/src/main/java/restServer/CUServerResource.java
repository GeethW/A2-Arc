package restServer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.restlet.resource.ServerResource;

import common.ContactUsData;
import common.ContactUsListWrapper;
import common.ContactUsResource;

public class CUServerResource extends ServerResource implements ContactUsResource {
	
	private static List<ContactUsData> data = Collections.synchronizedList(new ArrayList<ContactUsData>());
	
	public static void addCuData(ContactUsData cu) {
		data.add(cu);
	}

	@Override
	public ContactUsListWrapper retrieve() {
		return new ContactUsListWrapper(data);
	}

}
