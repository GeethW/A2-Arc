package Controllers;

import javax.servlet.http.*;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.*;

@WebServlet(urlPatterns={"/login"})
public class LogInController extends HttpServlet {
    /**
	 * Default
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException {
        String realUN = "Lexy99";
        String realPW = "password";
        String message = "";
        HttpSession session = req.getSession();

        String username = req.getParameter("uname");
        String password = req.getParameter("pw");
        if(password.contains(";") || username.contains(";"))
        {
        	message = "Username or password cannot contain ';'.";
        	session.setAttribute("loginStatus","unsuccessful");
        	session.setAttribute("error", message);
        	req.getRequestDispatcher("index.jsp").forward(req, res);
        }

        if(!realPW.equals(password) || !realUN.equals(username))
        {
            session.setAttribute("loginStatus","unsuccessful");
            message = "Incorrect username or password.";
        } else {
            session.setAttribute("loginStatus","successful");
        }
        session.setAttribute("error", message);
        message +=  ";" + username + ";" + password; //for logs
        
        try
    	{
    		Properties props = new Properties();
    		props.put(Context.PROVIDER_URL,"iiop://127.0.0.1:3700");  

    		Context context = new InitialContext(props);
    		TopicConnectionFactory tfactory = (TopicConnectionFactory) context.lookup("jms/Seng4400ConnectionFactory");	
    		
    		TopicConnection tconnection = tfactory.createTopicConnection();
    		TopicSession tsession = tconnection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
    		TopicPublisher publisher = tsession.createPublisher((Topic)context.lookup("jms/seng4400assign2PS"));

    		TextMessage msg = tsession.createTextMessage();
    		msg.setText(message);
    		publisher.publish(msg);

    		context.close();
    		tconnection.close();
    	}
    	catch (Exception e)
    	{
    			e.printStackTrace();
    	}

		//req.getRequestDispatcher("PersonalDetails.jsp").forward(req, res);
        req.getRequestDispatcher("index.jsp").forward(req, res);
    }

}
