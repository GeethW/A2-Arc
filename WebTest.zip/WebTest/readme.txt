If you see this error, 'java.lang.IllegalArgumentException: interface common.ContactUsResource is not visible from class loader' when
running the program on the server, try restarting Glassfish until it works. It's a seemingly random error.

Contact us page: http://seng4400-a2-p2.appspot.com/
Log in page: http://laptop-s99jhnrr:8080/SQ-A2/login - might be different on different laptops (just launch from glassfish)
Show 'contact us' logs and 'log in' logs page: http://laptop-s99jhnrr:8080/WebTest/  - might be different on different laptops (just 
launch from glassfish)