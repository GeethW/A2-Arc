

import java.io.IOException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.jms.*;

/**
 * Servlet implementation class Listener
 */
@WebServlet("/logins")
public class Listener extends HttpServlet implements MessageListener {
	private static final long serialVersionUID = 1L;
	private beans.Messages msges;
	private TopicConnection tconnection;
	private Context context;
	private TopicConnectionFactory tfactory;
	private Properties props;
	private TopicSession tsession;
	private TopicSubscriber subscriber;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Listener() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init() throws ServletException {
    	msges = new beans.Messages();
        getServletContext().setAttribute("Messages", msges);
        
        try
  		{
			props = new Properties();
			props.put(Context.PROVIDER_URL,"iiop://127.0.0.1:3700");  

			context = new InitialContext(props);
			tfactory = (TopicConnectionFactory) context.lookup("jms/Seng4400ConnectionFactory");	
			
			tconnection = tfactory.createTopicConnection();
			tsession = tconnection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
			subscriber = tsession.createSubscriber((Topic)context.lookup("jms/seng4400assign2PS"));

			subscriber.setMessageListener(this);

			tconnection.start();
		}
		catch (Exception e)
		{
				e.printStackTrace();
		}
    }
    
    public void onMessage(Message message)
	{
		if(message instanceof TextMessage)
		{
			try
			{
				String logData = ((TextMessage)message).getText();
				String[] inputs = logData.split(";");
				
				if(inputs.length==2)
					msges.addLog("", inputs[1], inputs[2]);
				else
					msges.addLog(inputs[0], inputs[1], inputs[2]);
				//System.out.println( ((TextMessage)message).getText());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
    
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException {
    	req.getRequestDispatcher("ViewLogs.jsp").forward(req, res);
    }

}
