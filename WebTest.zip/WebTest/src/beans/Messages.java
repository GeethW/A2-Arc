package beans;
import java.util.ArrayList;

public class Messages {
	private ArrayList<String> errors;
	private ArrayList<String> usernames;
	private ArrayList<String> passwords;

	public Messages()
	{
		errors = new ArrayList<String>();
		usernames = new ArrayList<String>();
		passwords = new ArrayList<String>();
	}
	
	public void addLog(String error, String username, String password)
	{
		errors.add(0, error);
		usernames.add(0, username);
		passwords.add(0, password);
	}
	
	public String getLogs()
	{
		int i = 0;
		String output = "";
		for(String e: errors)
		{
			if(e.equals(""))
			{
				output += "Login successful. ";
			} else {
				output += e + " ";
			}
			
			output += "Where username = " + usernames.get(i) + ", password = " + passwords.get(i) + ". \n";
			i++;
		}
		
		return output;
	}
	
	public int getLogCount()
	{
		return errors.size();
	}
	
	public String getLastXLogs(int limit)
	{
		int i = 0;
		String output = "";
		for(String e: errors)
		{
			if(i==50)
			{
				break;
			}
			
			if(e.equals(""))
			{
				output += "Login successful. ";
			} else {
				output += e + " ";
			}
			
			output += "Where username = " + usernames.get(i) + ", password = " + passwords.get(i) + ". \n";
			i++;
		}
		
		return output;
	}
}
