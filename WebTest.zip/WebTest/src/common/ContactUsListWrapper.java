package common;

import java.io.Serializable;
import java.util.List;

/*
 * This only exists because the converter is an idiot (can't preserve the generic type)
 */
public class ContactUsListWrapper implements Serializable {
	private static final long serialVersionUID = 1L;
	public List<ContactUsData> data;
	
	public ContactUsListWrapper() {
		data = null;
	}
	
	public ContactUsListWrapper(List<ContactUsData> data) {
		this.data = data;
	}
}
