package common;

import org.restlet.resource.Get;

public interface ContactUsResource {
	
	@Get
	public ContactUsListWrapper retrieve();

}
