package restClient;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.restlet.resource.ClientResource;

import common.ContactUsData;
import common.ContactUsListWrapper;
import common.ContactUsResource;

/**
 * Servlet implementation class Alyoo
 */
@WebServlet("/contactUs")
public class DisplayContactUs extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayContactUs() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PollGAE stuff = (PollGAE) getServletContext().getAttribute("pollData");
        
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        String output = "";
        
        synchronized(stuff) {
            output += "Last Update: " + stuff.getLastUpdate() + "<br><br>";
            for (int i = 0; i < stuff.getNumberOfData(); i++) {
                output += "Name: " + stuff.getData(i).getCustomerName() + "<br>";
                output += "Message: " + stuff.getData(i).getMsg() + "<br>";
            }
        }
        
        HttpSession session = request.getSession();
        session.setAttribute("output", output);
        request.getRequestDispatcher("ViewContactUs.jsp").forward(request, response);
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
