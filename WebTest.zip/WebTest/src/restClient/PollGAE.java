package restClient;

import java.util.Date;
import java.util.ArrayList;

import org.restlet.resource.ClientResource;

import common.ContactUsData;
import common.ContactUsListWrapper;
import common.ContactUsResource;

public class PollGAE implements Runnable {
    
    private volatile ContactUsListWrapper data;
    private volatile Date lastUpdate;
    
    public PollGAE() {
    	data = new ContactUsListWrapper(new ArrayList<>());
        lastUpdate = new Date(System.currentTimeMillis());
    }
    
    private synchronized void updateData(ContactUsListWrapper newData) {
        lastUpdate = new Date(System.currentTimeMillis());
        data = newData;
    }
    
    /*
     * Be sure to sync on this object first before using the getters
     */
    public ContactUsData getData(int i) {
        return data.data.get(i);
    }
    
    public int getNumberOfData() {
        return data.data.size();
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }
    /*
     * To stop just interrupt the thread this is running in
     */
    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                ClientResource cr = new ClientResource("http://seng4400-a2-p2.ts.r.appspot.com/rest/cudata");
                cr.setRequestEntityBuffering(true); //GAE doesn't support chunk encoding so this is a workaround
                ContactUsResource resource = cr.wrap(ContactUsResource.class);
                ContactUsListWrapper stuff = resource.retrieve();
                updateData(stuff);
                Thread.sleep(15000); // 15s
            } catch (InterruptedException e) {
                break;
            }
        }
    }

}