package restClient;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class PollListener
 *
 */
@WebListener
public class PollListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public PollListener() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
        Thread t = (Thread) sce.getServletContext().getAttribute("pollThread");
        t.interrupt();
        try {
            t.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); //propagate it up since this would be unexpected
        }
        sce.getServletContext().removeAttribute("pollData");
        sce.getServletContext().removeAttribute("pollThread");
    }

    /**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  {
        PollGAE poller = new PollGAE();
        Thread t = new Thread(poller);
        t.start();
        sce.getServletContext().setAttribute("pollData", poller);
        sce.getServletContext().setAttribute("pollThread", t);
    }
    
}